<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CompanyRate extends Model
{

    protected $table = 'companies_rates';
}
