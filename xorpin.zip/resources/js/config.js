// export const domain = 'http://localhost:8000'
// export const loginUrl = domain + 'oauth/token'
// export const userUrl = domain + 'api/user'
// export const nodeServer = 'http://localhost:8888'

// export const getHeader = function () {
//     const tokenData = JSON.parse(window.localStorage.getItem('authUser'))
//     let headers = {};
//     if (tokenData && tokenData.access_token) {
//         headers = {
//             Accept: 'application/json',
//             Authorization: 'Bearer ' + tokenData.access_token
//         }
//     }
//     return headers;
// }
